#!/bin/bash

echo "🏥 KDIC RIS - APK Builder"
echo "=========================="
echo ""

# Check if cordova is installed
if ! command -v cordova &> /dev/null
then
    echo "❌ Cordova not found!"
    echo ""
    echo "Please install Cordova first:"
    echo "npm install -g cordova"
    echo ""
    exit 1
fi

echo "✓ Cordova found"
echo ""

# Check if Android platform is added
if [ ! -d "platforms/android" ]; then
    echo "📱 Adding Android platform..."
    cordova platform add android
    echo "✓ Android platform added"
else
    echo "✓ Android platform already exists"
fi

echo ""
echo "🔨 Building APK..."
echo ""

cordova build android

echo ""
echo "✅ BUILD COMPLETE!"
echo ""
echo "📦 Your APK is located at:"
echo "platforms/android/app/build/outputs/apk/debug/app-debug.apk"
echo ""
echo "📲 To install:"
echo "1. Copy APK to your Android phone"
echo "2. Enable 'Install from Unknown Sources'"
echo "3. Open APK and install"
echo ""
